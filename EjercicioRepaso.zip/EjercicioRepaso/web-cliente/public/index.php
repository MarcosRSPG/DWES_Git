<?php

require_once __DIR__.'/../app/iniciador.php';

use Mrs\WebCliente\Core;

$init = new Core();
