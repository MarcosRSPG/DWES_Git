<?php

// Configuración de URLs
define('API_URL', 'http://mywww/EjercicioRepaso/api-server/public');
define('WEB_URL', 'http://mywww/EjercicioRepaso/web-cliente/public');

// Credenciales Basic Auth para consumir API
define('API_BASIC_USER', 'admin');
define('API_BASIC_PASS', 'admin123');
