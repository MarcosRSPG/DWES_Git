<hr>
<H3>AQUI TU FOOTER</H3>
<a href="mailto:restaurante@gmail.com">restaurante@gamil.com</a>
<script type="text/javascript" src="<?php echo RUTA_URL; ?>/js/main.js"></script>
</body>
</html>