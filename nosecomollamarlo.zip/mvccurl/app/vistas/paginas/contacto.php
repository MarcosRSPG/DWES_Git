<?php require_once RUTA_APP.'/vistas/inc/header.php';?>
<h1><?php echo $datos['titulo'];?></h1>

<h2>Página de Contacto</h2>


<?php require_once RUTA_APP.'/vistas/inc/footer.php';?>

