</main>
<footer class="footer">
  <div class="wrap">
    <small>DWES UD5 - MVC · <?= date('Y') ?></small>
  </div>
</footer>
</body>
</html>
